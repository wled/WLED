# ANIMartRIX

Addes the effects from ANIMartRIX to WLED

CC BY-NC 3.0 licensed effects by Stefan Petrick, include this usermod only if you accept the terms!

## Installation 

Add 'animartrix' to 'custom_usermods' in your platformio_override.ini.

