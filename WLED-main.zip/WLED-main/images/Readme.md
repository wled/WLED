### Additional Logos

Additional awesome logos for WLED can be found here [Aircoookie/Akemi](https://github.com/Aircoookie/Akemi).

<img src="https://github.com/Aircoookie/Akemi/blob/master/akemi/001_cheerful.png">
